import 'package:flutter/material.dart';

const LBgColor = Color(0xffD1D9E6);
const LPrimaryColor = Color(0xff246AFE);
const LLableColor = Color(0xff8C8C8C);
const LDivColor = Color(0xffFFFFFF);
const LFontColor = Color (0xff000000);

const DBgColor = Color(0xff242424);
const PrimaryColor = Color(0xff246AFE);
const DLableColor =Color(0xff8C8C8C);
const DDivColor = Color(0xff373737);
const DFontColor = Color(0xff000000);